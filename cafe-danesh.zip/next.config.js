module.exports = {
  // بدون output: 'export'
  images: {
    unoptimized: true,
  },
  eslint: {
    ignoreDuringBuilds: true,
  },
  experimental: {
    turbo: false,  // Turbopack را خاموش کن
  }
}