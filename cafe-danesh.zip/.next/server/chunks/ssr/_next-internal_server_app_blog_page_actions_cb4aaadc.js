module.exports=[29934,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_blog_page_actions_cb4aaadc.js.map