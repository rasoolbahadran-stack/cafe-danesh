module.exports=[9481,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_posts_page_actions_561c1a9b.js.map