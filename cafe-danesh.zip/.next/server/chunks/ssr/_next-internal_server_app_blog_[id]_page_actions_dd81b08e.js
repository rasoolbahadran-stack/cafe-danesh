module.exports=[61432,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_blog_%5Bid%5D_page_actions_dd81b08e.js.map