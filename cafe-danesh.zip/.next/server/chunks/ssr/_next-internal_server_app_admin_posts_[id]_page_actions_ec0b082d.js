module.exports=[10605,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_posts_%5Bid%5D_page_actions_ec0b082d.js.map